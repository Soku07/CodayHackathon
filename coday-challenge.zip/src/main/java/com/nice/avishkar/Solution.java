package com.nice.avishkar;

import java.nio.file.Path;

public class Solution {

	public ElectionResult execute(Path candidateFile, Path votingFile) {
		ElectionResult resultData = new ElectionResult();

		// Write code here to read CSV files and process them

		return resultData;
	}

}